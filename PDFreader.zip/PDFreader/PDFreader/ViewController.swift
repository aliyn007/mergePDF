//
//  ViewController.swift
//  PDFreader
//
//  Created by Александр on 18.01.2022.
//

import UIKit
import PDFKit
import MobileCoreServices
import UniformTypeIdentifiers

class ViewController: UIViewController,UINavigationControllerDelegate, UIImagePickerControllerDelegate,PDFViewDelegate,UIDocumentPickerDelegate, UIDocumentMenuDelegate {
    
    
    let pdf = PDFView()

    
    
    @IBOutlet weak var pdfImage: UIView!
    
   
    
    @IBOutlet weak var imageGallery: UIImageView!
    
    @IBOutlet weak var inPage: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pdfImage.addSubview(pdf)
        

           
    }
  
    
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pdf.frame = pdfImage.bounds
        pdf.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        
    }

    @IBAction func addImage(_ sender: Any) {
        openGallery()
    }
    
    
    
    @IBAction func updateFile(_ sender: Any) {
        addPDF()
    }
    
    
 
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            imageGallery.contentMode = .scaleAspectFit
            imageGallery.image = pickedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }

     func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {

         self.dismiss(animated: true, completion: nil)
    }
    
   func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let addPDF = urls.first else {return}
          
         let deviceDoc = PDFDocument(url:addPDF)
       let addPage = PDFPage(image:  imageGallery.image!)
         pdf.document = deviceDoc
        pdf.autoScales = true
         pdf.delegate = self
          let x = Int(inPage.text!)!
       deviceDoc?.insert(addPage!, at:x )
         deviceDoc?.write(to: addPDF)
   
          pdfImage.addSubview(pdf)
        
     
    }
          
    func documentMenu(_ documentMenu: UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
      self.present(documentPicker, animated: true, completion: nil)
    }
    


    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("view was cancelled")
        dismiss(animated: true, completion: nil)
    }
    func addPDF(){
        let supportedTypes : [UTType] = [UTType.pdf, UTType.image, UTType.png]
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = true
        documentPicker.modalPresentationStyle = .formSheet
        self.present(documentPicker, animated: true, completion: nil)
    }
    
    
    
    func openGallery() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
           // imagePicker.allowsEditing = true
            imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
            self.present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert  = UIAlertController(title: "Warning", message: "You don't have permission to access gallery.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    
   
}


